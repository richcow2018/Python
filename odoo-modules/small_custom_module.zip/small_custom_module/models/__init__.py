# -*- coding: utf-8 -*-

from . import small_custom_module
