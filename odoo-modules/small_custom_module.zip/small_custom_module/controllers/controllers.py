# -*- coding: utf-8 -*-
from odoo import http

# class SmallCustomModule(http.Controller):
#     @http.route('/small_custom_module/small_custom_module/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/small_custom_module/small_custom_module/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('small_custom_module.listing', {
#             'root': '/small_custom_module/small_custom_module',
#             'objects': http.request.env['small_custom_module.small_custom_module'].search([]),
#         })

#     @http.route('/small_custom_module/small_custom_module/objects/<model("small_custom_module.small_custom_module"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('small_custom_module.object', {
#             'object': obj
#         })